#include "Events.h"

Events::Events(GLFWwindow* window, double* originalPos, float speed)
{
	int i;
	this->window = window;
	for (i = 0; i < 2; i++)
	{
		this->originalPos[i] = *(originalPos + i);
		this->currentPos[i] = this->originalPos[i];
		this->temp_pos[i] = -1;
	}
	this->speed = speed;
	this->deg_x = 0, this->deg_y = 0;
	for (i = 0; i < 3; i++)
		this->position[i] = 0.0f;
}

Events::Events(GLFWwindow* window, float speed)
{
	this->window = window;
	glfwGetCursorPos(this->window, &this->originalPos[0], &this->originalPos[1]);
	this->currentPos[0] = this->originalPos[0];
	this->currentPos[1] = this->currentPos[1];
	this->speed = speed;
	this->deg_x = 0, this->deg_y = 0;
	for (int i = 0; i < 3; i++)
		this->position[i] = 0.0f;
}

void Events::update(glm::mat4* view, glm::mat4* rot)
{
	this->update_keyboard(view);
	this->update_mouse(rot);
}

void Events::update_keyboard(glm::mat4* view)
{
	int val1 = glfwGetKey(this->window, GLFW_KEY_W);
	int val2 = glfwGetKey(this->window, GLFW_KEY_UP);
	if (val1 == GLFW_PRESS || val2 == GLFW_PRESS)
		this->position[2] += speed;
	val1 = glfwGetKey(this->window, GLFW_KEY_S);
	val2 = glfwGetKey(this->window, GLFW_KEY_DOWN);
	if (val1 == GLFW_PRESS || val2 == GLFW_PRESS)
		this->position[2] -= speed;

	val1 = glfwGetKey(this->window, GLFW_KEY_A);
	val2 = glfwGetKey(this->window, GLFW_KEY_LEFT);
	if (val1 == GLFW_PRESS || val2 == GLFW_PRESS)
		this->position[0] -= speed;
	
	val1 = glfwGetKey(this->window, GLFW_KEY_D);
	val2 = glfwGetKey(this->window, GLFW_KEY_RIGHT);
	if (val1 == GLFW_PRESS || val2 == GLFW_PRESS)
		this->position[0] += 0.5 * speed;

	if (glfwGetKey(this->window, GLFW_KEY_SPACE) == GLFW_PRESS)
		this->position[1] -= 0.5 * speed;

	if (glfwGetKey(this->window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
		this->position[1] += speed;
	*view = glm::translate(glm::mat4(1.0), glm::vec3(this->position[0], this->position[1], this->position[2]));
}

void Events::update_mouse(glm::mat4* rot)
{
	this->temp_pos[0] = -1;
	this->temp_pos[1] = -1;
	glfwGetCursorPos(this->window, &temp_pos[0], &temp_pos[1]);
	if (this->temp_pos[0] == this->currentPos[0] && this->temp_pos[1] == this->currentPos[1])
		return;

	if (this->temp_pos[0] > this->currentPos[0])
		deg_y += 20 * speed;
	else if (this->temp_pos[0] < this->currentPos[0])
		deg_y -= 20 * speed;

	if (this->temp_pos[1] > this->currentPos[1])
		deg_x += 20 * speed;
	else if (this->temp_pos[1] < this->currentPos[1])
		deg_x -= 20 * speed;

	glm::mat4 rot_x = glm::rotate(glm::mat4(1.0), glm::radians(this->deg_x), glm::vec3(1.0f, 0.0f, 0.0f));
	glm::mat4 rot_y = glm::rotate(glm::mat4(1.0), glm::radians(this->deg_y), glm::vec3(0.0f, 1.0f, 0.0f));
	*rot = rot_x * rot_y;
	this->currentPos[0] = this->temp_pos[0];
	this->currentPos[1] = this->temp_pos[1];
}
