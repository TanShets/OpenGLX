//#include "Renderer.h"
#include "../Events.h"
//#include "Texture.h"
//#include "shapes/shapes.h"
//#include <GLFW/glfw3.h>

double currentPos[2] = { 0, 0 };
double originalPos[2] = { 0, 0 };
float factor = 0.05f;
void rotationx(GLFWwindow* window, glm::mat4* rot)
{
	double x, y;
	glm::mat4 result;
	glfwGetCursorPos(window, &x, &y);
	if (currentPos[0] == x && currentPos[1] == y)
		return;
	else if(currentPos[0] == x)
		result = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(y - currentPos[1])), glm::vec3(1.0f, 0.0f, 0.0f));
	else if(currentPos[1] == y)
		result = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(x - currentPos[0])), glm::vec3(0.0f, 1.0f, 0.0f));
	else
	{
		glm::mat4 mat_x = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(x - currentPos[0])), glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 mat_y = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(y - currentPos[1])), glm::vec3(1.0f, 0.0f, 0.0f));
		result = mat_x * mat_y;
	}
	//currentPos[0] = x;
	//currentPos[1] = y;
	if((glm::radians(factor * (float)(x - currentPos[0])) >= glm::radians(30.0f)) || (glm::radians(factor * (float)(y - currentPos[1])) >= glm::radians(30.0f))){
		currentPos[0] = x;
		currentPos[1] = y;
	}
	*rot = result;
}

void rotate(Vertex* data)
{
	float increment = 0.01;
	for (int i = 0; i < 8; i++)
	{
		/*
		if (data[i].position[0] >= 0 && data[i].position[0] <= 0.25 && \
			data[i].position[2] <= 0 && data[i].position[2] >= -0.25) {
			data[i].position[0] -= increment;
			data[i].position[2] -= increment;
		}
		else if (data[i].position[0] <= 0 && data[i].position[0] >= -0.25 &&\
			data[i].position[2] <= 0 && data[i].position[2] >= -0.25) {
			data[i].position[0] -= increment;
			data[i].position[2] += increment;
		}
		else if (data[i].position[0] >= 0 && data[i].position[0] <= 0.25 && \
			data[i].position[2] >= 0 && data[i].position[2] <= 0.25) {
			data[i].position[0] += increment;
			data[i].position[2] -= increment;
		}
		else if (data[i].position[0] <= 0 && data[i].position[0] >= -0.25 && \
			data[i].position[2] >= 0 && data[i].position[2] <= 0.25) {
			data[i].position[0] += increment;
			data[i].position[2] += increment;
		}
		*/

		//std::cout << i << " x: " << data[i].position[0] << " z: " << data[i].position[2] << std::endl;
		//data[i].position[0] += increment;
		//data[i].position[2] += increment;
	}
}

void print_perspective(const glm::mat4& val)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			std::cout << val[i][j] << " ";
		}
		std::cout << std::endl;
	}
}

int main() {
	//names shader = ParseShader("shaders/vertex.shader");
	//		std::string image_path = "Picture1.png";
	float color[] = {((float)(rand() % 10) / 10), ((float)(rand() % 10) / 10), ((float)(rand() % 10) / 10), ((float)(rand() % 10) / 10)};
	float origin[] = { 0.0f, 0.0f, 0.0f };
	double pi = acos(-1.0);
	std::cout << "pi " << (float)pi / 3 << std::endl;
	glm::mat4 proj = glm::perspective((float)pi / 3, (float)600 / (float)600, (float)0.2f, (float)50.0f);
		//glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -50.0f, 50.0f);
	//glm::mat4 model = glm::perspective((float)pi / 3, (float)600 / (float)600, (float)-1.0f, (float)1.0f);
	glm::mat4 rot = glm::rotate(glm::mat4(1.0f), glm::radians(20.0f), glm::vec3(1.0, 0.0, 0.0));
	glm::mat4 view = /*glm::lookAt(glm::vec3(0.f, 0.f, 1.f), glm::vec3(0.f, 1.f, 0.f), glm::vec3(0.f, 0.f, -1.f));*/\
		glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -1.0f));
	glm::mat4 mvp = proj * view * rot;// *model;
	print_perspective(proj);
	print_perspective(view);
	//print_perspective(model);
	print_perspective(mvp);
	//glm::mat4 model;
	float z = -0.1f;
	//const char* ty = anon.c_str();
	GLFWwindow* window;
	if (glfwInit() == -1)
		return -1;
	window = glfwCreateWindow(600, 600, "The Window", NULL, NULL);
	if (!window) {
		glfwTerminate();
		return -1;
	}
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	//double x, y;
	glfwGetCursorPos(window, &originalPos[0], &originalPos[1]);
	currentPos[0] = originalPos[0];
	currentPos[1] = originalPos[1];
	//std::cout << "Mouse " << x << " " << y << std::endl;
	/*
	Vertex positions[] = {
		{{-0.9f, -0.9f, 0.0f}, {0.5, 0.1, 0.7, 1.0}},	//{0.0f, 0.0f}},
		{ {0.9f, -0.9f, 1.0f}, {0.1, 0.5, 1.0, 1.0}},//, {1.0f, 0.0f} },
		{{0.9f, 0.9f, 0.3f}, {1.0, 0.7, 1.0, 1.0}},//, {1.0f, 1.0f}},
		{{-0.9f, 0.9f, 0.6f}, {1.0, 1.0, 0.5, 1.0}}//, {0.0f, 1.0f}},
		//	{{-0.5f, 0.0f, 0.7f}, {0.1, 1.0, 0.7, 1.0}},//, {0.0f, 0.0f}},
		//	 {{0.5f, 0.0f, -0.2f }, {1.0, 1.0, 1.0, 1.0}},//, {1.0f, 0.0f}},
		//	{{0.5f, 0.5f, -0.1f }, {0.1, 0.5, 0.7, 1.0}},//, { 1.0f, 1.0f }},
		//	{{-0.5f, 0.5f, -0.5f }, {0.7, 1.0, 0.1, 1.0}}//, {0.0f, 1.0f}}
	};
	*/

	Vertex positions[] = {
		{{-0.5, -0.5, -0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{0.5, -0.5, -0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{-0.5, 0.5, -0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{0.5, 0.5, -0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{-0.5, -0.5, 0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{0.5, -0.5, 0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{-0.5, 0.5, 0.5}, {0.5, 0.1, 0.7, 1.0}},
		{{0.5, 0.5, 0.5}, {0.5, 0.1, 0.7, 1.0}},
	};

	Vertex positions2[] = {
		{{-0.5f, 0.0f, 0.0f}, {0.8, 1.0, 0.3, 1.0}},//, {0.0f, 0.0f}},
		{{0.5f, 0.0f, -0.5f }, {0.7, 0.7, 1.0, 1.0}},//, {1.0f, 0.0f}},
		{{0.5f, 0.5f, -0.2f }, {1.0, 0.1, 1.0, 1.0}},//, { 1.0f, 1.0f }},
		{{-0.5f, 0.5f, 0.6f}, {0.4, 1.0, 0.2, 1.0}},//, {0.0f, 1.0f}}
	};
	/*
	unsigned int indices[] = {
		0, 1, 2,
		2, 3, 0,
		//4, 5, 6,
		//6, 7, 4
	};
	*/
	unsigned int indices[] = {
		0, 1, 2,
		1, 3, 2,
		4, 5, 6,
		5, 7, 6
	};
	//unsigned int /*buffer, indexBuffer, */vertexArray;
	glfwMakeContextCurrent(window);
	if (glewInit() != GLEW_OK)
		return -1;
	Cube cube(origin, 0.3, color);
	float* v = cube.getOrigin();
	//std::cout << v[0] << " " << v[1] << " " << v[2] << std::endl;
	Vertex* data = cube.getData();
	Renderer renderer;
	Shaders shader;
	VertexArray vertexArray;
	VertexArray vertexArray2;
	//glGenVertexArrays(1, &vertexArray);
	//glGenBuffers(1, &buffer);
	//	VertexBuffer buffer((const void*)positions, 8 * sizeof(Vertex));
	VertexBuffer buffer((const void*)data, 8 * sizeof(Vertex));
	VertexBufferLayout vbLayout;
	vbLayout.Push<float>(3);
	vbLayout.Push<float>(4);
	VertexBuffer buffer2((const void*)positions2, 4 * sizeof(Vertex));
	VertexBufferLayout vbLayout2;
	vbLayout2.Push<float>(3);
	vbLayout2.Push<float>(4);
	//	IndexBuffer indexBuffer(indices, 12);
	IndexBuffer indexBuffer((unsigned int*)cube.getIndex(), 36);
	vertexArray.Bind();
	buffer.Bind();
	indexBuffer.Bind();
	vertexArray.AddBuffer(buffer, vbLayout);
	indexBuffer.UnBind();
	vertexArray.UnBind();

	vertexArray2.Bind();
	buffer2.Bind();
	indexBuffer.Bind();
	vertexArray2.AddBuffer(buffer2, vbLayout2);
	indexBuffer.UnBind();
	vertexArray2.UnBind();
	shader.BindShader();
	//	Texture texture("Picture1.png");
	//	texture.Bind();
	//GLint u_texture = 0;
	//glBindBuffer(GL_ARRAY_BUFFER, 0);
	GLfloat colors[4];
	GLfloat xx = 0;
	GLint anony = 0;
	glm::vec4 anon;
	float increment = 0.005;
	Events event(window, originalPos, (float)0.5);
	while (!glfwWindowShouldClose(window)) {
		glfwSwapInterval(5);
		//glClear(GL_COLOR_BUFFER_BIT);
		renderer.Clear();
		positions2[0].position[0] -= increment;
		positions2[1].position[0] -= increment;
		positions2[2].position[0] -= increment;
		positions2[3].position[0] -= increment;
		//positions2[0].position[2] -= increment;
		//positions2[1].position[2] -= increment;
		//positions2[2].position[2] -= increment;
		//positions2[3].position[2] -= increment;
		//	rotate(data);
		buffer.update(data, 8 * sizeof(Vertex));
		buffer2.update(positions2, 4 * sizeof(Vertex));
		z += increment;
		//rot = rotationx(window);
		//	rotationx(window, &rot);
		event.update(&view, &rot);
		//view = glm::translate(glm::mat4(1.0f), glm::vec3(0.0, 0.0, z));
		//model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0, 0.0, z));
		mvp = proj * view * rot;// *model;
		//vertexArray.Bind();
		//indexBuffer.Bind();
		colors[0] = (GLfloat)((float)(rand() % 10) / 10);
		colors[1] = (GLfloat)((float)(rand() % 10) / 10);
		colors[2] = (GLfloat)((float)(rand() % 10) / 10);
		colors[3] = 1.0f;
		//shader.uniformChange('M', 4, (void*)&proj, "proj");
		//shader.uniformChange('M', 4, (void*)&view, "view");
		//anon = view * glm::vec4(data[7].position[0], data[7].position[1], data[7].position[2], 1.0f);
		//anon = proj * anon;
		//std::cout << "Vertex: " << anon[0] << " " << anon[1] << " " << anon[2] << std::endl;
		shader.uniformChange('M', 4, (void*)&mvp, "u_MVP");
		//	shader.uniformChange('i', 1, (void*)&anony, "u_Texture");
		//shader.uniformChange('ffff', 1, &xx, "diss");
		//	shader.uniformChange('f', 4, colors, "u_Color");
		renderer.Draw(&vertexArray, &indexBuffer, shader);
		//renderer.Draw(&vertexArray2, &indexBuffer, shader);
		//glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
		//glfwGetCursorPos(window, &x, &y);
		//std::cout << "Mouse " << x << " " << y << std::endl;
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	//glDeleteProgram(program);
	//glDisable(GL_BLEND);
	shader.deleteShader();
	glfwTerminate();
	return 0;
}

/*
	Now able to render textures, still w/o blending.
*/