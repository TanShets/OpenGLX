#include "src/Renderer.h"
#include <GLFW/glfw3.h>
class Events
{
	private:
		GLFWwindow* window;
		double originalPos[2], currentPos[2], temp_pos[2];
		float speed, position[3], deg_x, deg_y;
	public:
		Events(GLFWwindow* window, double* originalPos, float speed);
		Events(GLFWwindow* window, float speed);
		void update(glm::mat4* view, glm::mat4* rot);
		void update_keyboard(glm::mat4* view);
		void update_mouse(glm::mat4* rot);
};

