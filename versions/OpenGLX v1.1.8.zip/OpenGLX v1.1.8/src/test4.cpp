//#include "Renderer.h"
#include "../Events.h"
#include <iostream>
//#include "Texture.h"
//#include "shapes/shapes.h"
//#include <GLFW/glfw3.h>

double currentPos[2] = { 0, 0 };
double originalPos[2] = { 0, 0 };
float factor = 0.05f;
void rotationx(GLFWwindow* window, glm::mat4* rot)
{
	double x, y;
	glm::mat4 result;
	glfwGetCursorPos(window, &x, &y);
	if (currentPos[0] == x && currentPos[1] == y)
		return;
	else if(currentPos[0] == x)
		result = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(y - currentPos[1])), glm::vec3(1.0f, 0.0f, 0.0f));
	else if(currentPos[1] == y)
		result = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(x - currentPos[0])), glm::vec3(0.0f, 1.0f, 0.0f));
	else
	{
		glm::mat4 mat_x = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(x - currentPos[0])), glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 mat_y = glm::rotate(glm::mat4(1.0), glm::radians(factor * (float)(y - currentPos[1])), glm::vec3(1.0f, 0.0f, 0.0f));
		result = mat_x * mat_y;
	}
	//currentPos[0] = x;
	//currentPos[1] = y;
	if((glm::radians(factor * (float)(x - currentPos[0])) >= glm::radians(30.0f)) || (glm::radians(factor * (float)(y - currentPos[1])) >= glm::radians(30.0f))){
		currentPos[0] = x;
		currentPos[1] = y;
	}
	*rot = result;
}

void rotate(Vertex* data)
{
	float increment = 0.01;
	for (int i = 0; i < 8; i++)
	{
		/*
		if (data[i].position[0] >= 0 && data[i].position[0] <= 0.25 && \
			data[i].position[2] <= 0 && data[i].position[2] >= -0.25) {
			data[i].position[0] -= increment;
			data[i].position[2] -= increment;
		}
		else if (data[i].position[0] <= 0 && data[i].position[0] >= -0.25 &&\
			data[i].position[2] <= 0 && data[i].position[2] >= -0.25) {
			data[i].position[0] -= increment;
			data[i].position[2] += increment;
		}
		else if (data[i].position[0] >= 0 && data[i].position[0] <= 0.25 && \
			data[i].position[2] >= 0 && data[i].position[2] <= 0.25) {
			data[i].position[0] += increment;
			data[i].position[2] -= increment;
		}
		else if (data[i].position[0] <= 0 && data[i].position[0] >= -0.25 && \
			data[i].position[2] >= 0 && data[i].position[2] <= 0.25) {
			data[i].position[0] += increment;
			data[i].position[2] += increment;
		}
		*/

		//std::cout << i << " x: " << data[i].position[0] << " z: " << data[i].position[2] << std::endl;
		//data[i].position[0] += increment;
		//data[i].position[2] += increment;
	}
}

void print_perspective(const glm::mat4& val)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			std::cout << val[i][j] << " ";
		}
		std::cout << std::endl;
	}
}

int main() {
	//std::cout << (double)glm::radians(180.0f) << std::endl;
	//names shader = ParseShader("shaders/vertex.shader");
	//		std::string image_path = "Picture1.png";
	float color[] = {((float)(rand() % 10) / 10), ((float)(rand() % 10) / 10), ((float)(rand() % 10) / 10), ((float)(rand() % 10) / 10)};
	float origin[] = { 0.0f, 0.0f, 0.0f };
	double pi = acos(-1.0);
	std::cout << "pi " << (float)pi / 3 << std::endl;
	glm::mat4 proj = glm::perspective((float)(2 * pi / 3), (float)600 / (float)600, (float)0.2f, (float)50.0f);
		//glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -50.0f, 50.0f);
	//glm::mat4 model = glm::perspective((float)pi / 3, (float)600 / (float)600, (float)-1.0f, (float)1.0f);
	glm::mat4 rot = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
	glm::mat4 view(1.0f);
	glm::mat4 mvp = proj * view * rot;// *model;
	print_perspective(proj);
	print_perspective(view);
	//print_perspective(model);
	print_perspective(mvp);
	//glm::mat4 model;
	float z = -0.1f;
	//const char* ty = anon.c_str();
	GLFWwindow* window;
	if (glfwInit() == -1)
		return -1;
	window = glfwCreateWindow(600, 600, "The Window", NULL, NULL);
	if (!window) {
		glfwTerminate();
		return -1;
	}
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	//double x, y;
	glfwGetCursorPos(window, &originalPos[0], &originalPos[1]);
	currentPos[0] = originalPos[0];
	currentPos[1] = originalPos[1];
	Vertex positions2[] = {
		{{-0.5f, 0.0f, 0.0f}, {0.8, 1.0, 0.3, 1.0}},//, {0.0f, 0.0f}},
		{{0.5f, 0.0f, -0.5f }, {0.7, 0.7, 1.0, 1.0}},//, {1.0f, 0.0f}},
		{{0.5f, 0.5f, -0.2f }, {1.0, 0.1, 1.0, 1.0}},//, { 1.0f, 1.0f }},
		{{-0.5f, 0.5f, 0.6f}, {0.4, 1.0, 0.2, 1.0}},//, {0.0f, 1.0f}}
	};
	/*
	unsigned int indices[] = {
		0, 1, 2,
		2, 3, 0,
		//4, 5, 6,
		//6, 7, 4
	};
	*/
	unsigned int indices[] = {
		0, 1, 2,
		1, 3, 2,
		4, 5, 6,
		5, 7, 6
	};
	//unsigned int /*buffer, indexBuffer, */vertexArray;
	glfwMakeContextCurrent(window);
	if (glewInit() != GLEW_OK)
		return -1;
	//IndexBuffer id;
	Cube cube(origin, 0.5, color);
	float origin2[3] = { 0.0f, 0.0f, 0.5f };
	Cube cube2(origin2, 0.5, color);
	float* v = cube.getOrigin();
	//std::cout << v[0] << " " << v[1] << " " << v[2] << std::endl;
	Vertex* data = (Vertex*)(cube.getData());
	Renderer renderer;
	Shaders shader;
	data = (Vertex*)(cube.getData());
	VertexArray vertexArray;
	VertexArray vertexArray2;
	//glGenVertexArrays(1, &vertexArray);
	//glGenBuffers(1, &buffer);
	//	VertexBuffer buffer((const void*)positions, 8 * sizeof(Vertex));
	//			VertexBuffer buffer(data, 8);
	VertexBuffer buffer;
	cube.AddtoBuffer(&buffer);
	cube2.AddtoBuffer(&buffer);
	VertexBufferLayout vbLayout;
	vbLayout.Push<float>(3);
	vbLayout.Push<float>(4);
	VertexBuffer buffer2(positions2, 4);
	VertexBufferLayout vbLayout2;
	vbLayout2.Push<float>(3);
	vbLayout2.Push<float>(4);
	//	IndexBuffer indexBuffer(indices, 12);
	//			IndexBuffer indexBuffer((unsigned int*)cube.getIndex(), 36);
	vertexArray.Bind();
	buffer.Bind();
	buffer.indexBuffer->Bind();
	//			indexBuffer.Bind();
	vertexArray.AddBuffer(buffer, vbLayout);
	//			indexBuffer.UnBind();
	vertexArray.UnBind();
	buffer.indexBuffer->UnBind();

	vertexArray2.Bind();
	buffer2.Bind();
	//			indexBuffer.Bind();
	vertexArray2.AddBuffer(buffer2, vbLayout2);
	//			indexBuffer.UnBind();
	vertexArray2.UnBind();
	shader.BindShader();
	GLfloat colors[4];
	GLfloat xx = 0;
	GLint anony = 0;
	glm::vec4 anon;
	float increment = 0.005;
	glm::vec4 useMe(0.0f, 0.0f, 0.0f, 1.0f);
	Events event(window, originalPos, (float)0.5);
	while (!glfwWindowShouldClose(window)) {
		glfwSwapInterval(5);
		//glClear(GL_COLOR_BUFFER_BIT);
		renderer.Clear();
		positions2[0].position[0] -= increment;
		positions2[1].position[0] -= increment;
		positions2[2].position[0] -= increment;
		positions2[3].position[0] -= increment;
		//positions2[0].position[2] -= increment;
		//positions2[1].position[2] -= increment;
		//positions2[2].position[2] -= increment;
		//positions2[3].position[2] -= increment;
		//	rotate(data);
		//			buffer.update(data, 8 * sizeof(Vertex));
		buffer2.update(positions2, 4 * sizeof(Vertex));
		z += increment;
		//rot = rotationx(window);
		//	rotationx(window, &rot);
		event.update(&view);
		mvp = proj * rot * view;// *model;
		//			useMe = glm::vec4(data[0].position[0], data[0].position[1], data[0].position[2], 1.0f);
		//			useMe = mvp * useMe;
		//			std::cout << "VertexX: " << data[0].position[0] << " " << useMe[1] << " " << useMe[2] << std::endl;
		//vertexArray.Bind();
		//indexBuffer.Bind();
		colors[0] = (GLfloat)((float)(rand() % 10) / 10);
		colors[1] = (GLfloat)((float)(rand() % 10) / 10);
		colors[2] = (GLfloat)((float)(rand() % 10) / 10);
		colors[3] = 1.0f;
		shader.uniformChange('M', 4, (void*)&proj, "proj");
		shader.uniformChange('M', 4, (void*)&view, "view");
		//		std::cout << "Position of origin: " << tempx[0] << " " << tempx[1] << " " << tempx[2] << std::endl;
		shader.uniformChange('M', 4, (void*)&mvp, "u_MVP");
		renderer.Draw(&vertexArray, buffer.indexBuffer, shader);
		//			renderer.Draw(&vertexArray, &indexBuffer, shader);
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	//glDeleteProgram(program);
	//glDisable(GL_BLEND);
	shader.deleteShader();
	glfwTerminate();
	return 0;
}

/*
	Now able to render textures, still w/o blending.
*/